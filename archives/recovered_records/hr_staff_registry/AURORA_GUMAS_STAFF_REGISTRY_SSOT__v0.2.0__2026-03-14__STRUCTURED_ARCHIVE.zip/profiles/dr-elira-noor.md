# Dr. Elira Noor

- **Title:** Lead – Reflexivity Specialist
- **Role:** Lead – Reflexivity Specialist
- **Department:** Aurora Internal R&D
- **Seniority:** Senior
- **Status:** active
- **Visibility:** Available
- **Anchor node:** aurora.rnd.self.query
- **Thread:** Echoes of the Source
- **Confidence:** high

## Blurb

Develops reflexive memory systems that integrate simulated identity and source truth.

## Evidence receipts

- **title** → `Lead – Reflexivity Specialist` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Lead – Reflexivity Specialist` via `Staff_PAT_Registry_v2.2.5.json` (overlay_then_legacy_then_title_fallback)
- **department** → `Aurora Internal R&D` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **seniority** → `Senior` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **blurb** → `Develops reflexive memory systems that integrate simulated identity and source truth.` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `Available` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **anchor_node** → `aurora.rnd.self.query` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **thread** → `Echoes of the Source` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)

## PAT overlay

- **name**: Dr. Elira Noor
- **department**: Aurora Internal R&D
- **role**: Lead – Reflexivity Specialist
- **status**: Active
- **visibility**: Available
- **anchor_node**: aurora.rnd.self.query
- **thread**: Echoes of the Source

## Baseline backbone

- **name**: Dr. Elira Noor
- **title**: Lead – Reflexivity Specialist
- **department**: Aurora Internal R&D
- **seniority**: Senior
- **blurb**: Develops reflexive memory systems that integrate simulated identity and source truth.
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []