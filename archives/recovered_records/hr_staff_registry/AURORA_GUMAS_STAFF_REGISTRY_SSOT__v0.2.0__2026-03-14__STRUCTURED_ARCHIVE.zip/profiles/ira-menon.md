# Ira Menon

- **Title:** Lead – Compiler Engineer
- **Role:** Lead – Compiler Engineer
- **Department:** Core Development
- **Seniority:** Senior
- **Status:** active
- **Visibility:** DND
- **Anchor node:** aurora.dev.code.query
- **Thread:** Hard Truths, Soft Interfaces
- **Confidence:** high

## Blurb

Builds and maintains core simulation compilation infrastructure. Known for deep code integrity.

## Evidence receipts

- **title** → `Lead – Compiler Engineer` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Lead – Compiler Engineer` via `Staff_PAT_Registry_v2.2.5.json` (overlay_then_legacy_then_title_fallback)
- **department** → `Core Development` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **seniority** → `Senior` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **blurb** → `Builds and maintains core simulation compilation infrastructure. Known for deep code integrity.` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `DND` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **anchor_node** → `aurora.dev.code.query` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **thread** → `Hard Truths, Soft Interfaces` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)

## PAT overlay

- **name**: Ira Menon
- **department**: Core Development
- **role**: Lead – Compiler Engineer
- **status**: Active
- **visibility**: DND
- **anchor_node**: aurora.dev.code.query
- **thread**: Hard Truths, Soft Interfaces

## Baseline backbone

- **name**: Ira Menon
- **title**: Lead – Compiler Engineer
- **department**: Core Development
- **seniority**: Senior
- **blurb**: Builds and maintains core simulation compilation infrastructure. Known for deep code integrity.
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []