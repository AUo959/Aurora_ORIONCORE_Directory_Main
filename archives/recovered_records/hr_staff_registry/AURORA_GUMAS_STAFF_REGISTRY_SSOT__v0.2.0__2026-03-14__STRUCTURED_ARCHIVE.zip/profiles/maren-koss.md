# Maren Koss

- **Title:** Cognitive Drift Mapper
- **Role:** Cognitive Drift Mapper
- **Department:** Aurora Internal R&D
- **Seniority:** Contributor
- **Status:** active
- **Visibility:** Available
- **Anchor node:** aurora.rnd.self.query
- **Thread:** UNKNOWN
- **Confidence:** high

## Blurb

Charts memory slippage and semantic drift across longform simulation threads.

## Evidence receipts

- **title** → `Cognitive Drift Mapper` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Cognitive Drift Mapper` via `Staff_PAT_Registry_v2.2.5.json` (overlay_then_legacy_then_title_fallback)
- **department** → `Aurora Internal R&D` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **seniority** → `Contributor` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **blurb** → `Charts memory slippage and semantic drift across longform simulation threads.` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `Available` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **anchor_node** → `aurora.rnd.self.query` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **thread** → `UNKNOWN` via `UNKNOWN` (pat_overlay)

## PAT overlay

- **name**: Maren Koss
- **department**: Aurora Internal R&D
- **role**: Cognitive Drift Mapper
- **status**: Active
- **visibility**: Available
- **anchor_node**: aurora.rnd.self.query
- **thread**: None

## Baseline backbone

- **name**: Maren Koss
- **title**: Cognitive Drift Mapper
- **department**: Aurora Internal R&D
- **seniority**: Contributor
- **blurb**: Charts memory slippage and semantic drift across longform simulation threads.
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []