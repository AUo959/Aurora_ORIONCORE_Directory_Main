# Prof. Elena Sorensen

- **Title:** Cognitive Science & Narrative Expert
- **Role:** Cognitive Science & Narrative Expert (Original Panel)
- **Department:** AI & Cognitive Systems
- **Seniority:** Senior
- **Status:** active
- **Visibility:** UNKNOWN
- **Anchor node:** UNKNOWN
- **Thread:** UNKNOWN
- **Confidence:** medium

## Blurb

Maps psychological models to AI interaction design and symbolic alignment protocols.

## Evidence receipts

- **title** → `Cognitive Science & Narrative Expert` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Cognitive Science & Narrative Expert (Original Panel)` via `GUMAS_Full_Team_Roster_Final.html` (overlay_then_legacy_then_title_fallback)
- **department** → `AI & Cognitive Systems` via `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` (alias_expansion_from_enriched_view)
- **seniority** → `Senior` via `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` (prefer_enriched_non_generic_rank)
- **blurb** → `Maps psychological models to AI interaction design and symbolic alignment protocols.` via `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **anchor_node** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **thread** → `UNKNOWN` via `UNKNOWN` (pat_overlay)

## Alternate observations

- **department:** AI Ethics / Narrative [Aurora_GUMAS_Staff_Tracker_v2.2.5.json]
- **seniority:** Contributor [Aurora_GUMAS_Staff_Tracker_v2.2.5.json]
- **blurb:** Elena maps psychological models to AI interaction design and symbolic alignment protocols. [Aurora_GUMAS_Staff_Registry_v2.2.5.html] | Focused on ensuring that the simulation’s memory system mirrors realistic human memory behavior through selective forgetting, conflict resolution, and narrative summarization. [GUMAS_Full_Team_Roster_Final.html]

## Baseline backbone

- **name**: Prof. Elena Sorensen
- **title**: Cognitive Science & Narrative Expert
- **department**: AI Ethics / Narrative
- **seniority**: Contributor
- **blurb**: None
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []