# Haneul Park

- **Title:** Immersive Experience Theorist
- **Role:** Immersive Experience Theorist
- **Department:** Cross-Domain R&D
- **Seniority:** Core Contributor
- **Status:** active
- **Visibility:** Available
- **Anchor node:** aurora.rnd.crossdomain.query
- **Thread:** UNKNOWN
- **Confidence:** high

## Blurb

Prototypes cognitive immersion structures for symbolic presence and lived participation.

## Evidence receipts

- **title** → `Immersive Experience Theorist` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Immersive Experience Theorist` via `Staff_PAT_Registry_v2.2.5.json` (overlay_then_legacy_then_title_fallback)
- **department** → `Cross-Domain R&D` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **seniority** → `Core Contributor` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **blurb** → `Prototypes cognitive immersion structures for symbolic presence and lived participation.` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `Available` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **anchor_node** → `aurora.rnd.crossdomain.query` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **thread** → `UNKNOWN` via `UNKNOWN` (pat_overlay)

## PAT overlay

- **name**: Haneul Park
- **department**: Cross-Domain R&D
- **role**: Immersive Experience Theorist
- **status**: Active
- **visibility**: Available
- **anchor_node**: aurora.rnd.crossdomain.query
- **thread**: None

## Baseline backbone

- **name**: Haneul Park
- **title**: Immersive Experience Theorist
- **department**: Cross-Domain R&D
- **seniority**: Core Contributor
- **blurb**: Prototypes cognitive immersion structures for symbolic presence and lived participation.
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []