# Emily Roberts

- **Title:** LLM-to-Simulation Bridge Developer
- **Role:** LLM-to-Simulation Bridge Developer
- **Department:** AI Systems
- **Seniority:** Contributor
- **Status:** active
- **Visibility:** UNKNOWN
- **Anchor node:** UNKNOWN
- **Thread:** UNKNOWN
- **Confidence:** high

## Blurb

Develops and maintains the interface between the memory system and the narrative AI, optimizing prompt integration and ensuring critical contextual information is available.

## Evidence receipts

- **title** → `LLM-to-Simulation Bridge Developer` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `LLM-to-Simulation Bridge Developer` via `GUMAS_Full_Team_Roster_Final.html` (overlay_then_legacy_then_title_fallback)
- **department** → `AI Systems` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **seniority** → `Contributor` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **blurb** → `Develops and maintains the interface between the memory system and the narrative AI, optimizing prompt integration and ensuring critical contextual information is available.` via `GUMAS_Full_Team_Roster_Final.html` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **anchor_node** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **thread** → `UNKNOWN` via `UNKNOWN` (pat_overlay)

## Baseline backbone

- **name**: Emily Roberts
- **title**: LLM-to-Simulation Bridge Developer
- **department**: AI Systems
- **seniority**: Contributor
- **blurb**: None
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []