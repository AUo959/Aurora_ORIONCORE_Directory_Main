# Naomi Vell

- **Title:** Narrative Framework Engineer
- **Role:** Narrative Framework Engineer
- **Department:** Narrative & Ethical Integration
- **Seniority:** Senior
- **Status:** active
- **Visibility:** UNKNOWN
- **Anchor node:** UNKNOWN
- **Thread:** UNKNOWN
- **Confidence:** medium

## Blurb

Ensures narrative continuity, symbolic integration, and ethical alignment through story structure and team rituals.

## Evidence receipts

- **title** → `Narrative Framework Engineer` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Narrative Framework Engineer` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (overlay_then_legacy_then_title_fallback)
- **department** → `Narrative & Ethical Integration` via `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` (alias_expansion_from_enriched_view)
- **seniority** → `Senior` via `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` (prefer_enriched_non_generic_rank)
- **blurb** → `Ensures narrative continuity, symbolic integration, and ethical alignment through story structure and team rituals.` via `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **anchor_node** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **thread** → `UNKNOWN` via `UNKNOWN` (pat_overlay)

## Alternate observations

- **department:** Ethics/Narrative [Aurora_GUMAS_Staff_Tracker_v2.2.5.json]
- **seniority:** Contributor [Aurora_GUMAS_Staff_Tracker_v2.2.5.json]
- **blurb:** Naomi ensures narrative continuity, symbolic integration, and ethical alignment through story structure and team rituals. [Aurora_GUMAS_Staff_Registry_v2.2.5.html]

## Baseline backbone

- **name**: Naomi Vell
- **title**: Narrative Framework Engineer
- **department**: Ethics/Narrative
- **seniority**: Contributor
- **blurb**: None
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []