# Helena Vu

- **Title:** Head of Human Resources
- **Role:** Head of Human Resources
- **Department:** Personnel & Mediation Systems
- **Seniority:** Senior
- **Status:** active
- **Visibility:** UNKNOWN
- **Anchor node:** UNKNOWN
- **Thread:** UNKNOWN
- **Confidence:** medium
- **Review flags:** title_conflict

## Blurb

Cultivates psychological safety and interpersonal clarity. Responsible for HR logic nodes and mediation frameworks.

## Evidence receipts

- **title** → `Head of Human Resources` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Head of Human Resources` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (overlay_then_legacy_then_title_fallback)
- **department** → `Personnel & Mediation Systems` via `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` (alias_expansion_from_enriched_view)
- **seniority** → `Senior` via `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` (prefer_enriched_non_generic_rank)
- **blurb** → `Cultivates psychological safety and interpersonal clarity. Responsible for HR logic nodes and mediation frameworks.` via `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **anchor_node** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **thread** → `UNKNOWN` via `UNKNOWN` (pat_overlay)

## Alternate observations

- **title:** HR Lead [Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html]
- **department:** HR [Aurora_GUMAS_Staff_Tracker_v2.2.5.json]
- **seniority:** Contributor [Aurora_GUMAS_Staff_Tracker_v2.2.5.json]
- **blurb:** Helena cultivates psychological safety and interpersonal clarity. Responsible for HR logic nodes and mediation frameworks. [Aurora_GUMAS_Staff_Registry_v2.2.5.html]

## Baseline backbone

- **name**: Helena Vu
- **title**: Head of Human Resources
- **department**: HR
- **seniority**: Contributor
- **blurb**: None
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []