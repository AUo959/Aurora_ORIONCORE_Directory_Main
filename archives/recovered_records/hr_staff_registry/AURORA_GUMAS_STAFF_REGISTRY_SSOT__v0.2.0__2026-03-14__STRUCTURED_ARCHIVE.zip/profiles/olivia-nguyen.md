# Olivia Nguyen

- **Title:** QA & Testing Engineer
- **Role:** Quality Assurance & Testing Engineer
- **Department:** Diagnostics
- **Seniority:** Contributor
- **Status:** active
- **Visibility:** UNKNOWN
- **Anchor node:** UNKNOWN
- **Thread:** UNKNOWN
- **Confidence:** high

## Blurb

Develops and executes comprehensive test plans to validate the robustness and performance of the memory module, ensuring all components meet quality standards.

## Evidence receipts

- **title** → `QA & Testing Engineer` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Quality Assurance & Testing Engineer` via `GUMAS_Full_Team_Roster_Final.html` (overlay_then_legacy_then_title_fallback)
- **department** → `Diagnostics` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **seniority** → `Contributor` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **blurb** → `Develops and executes comprehensive test plans to validate the robustness and performance of the memory module, ensuring all components meet quality standards.` via `GUMAS_Full_Team_Roster_Final.html` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **anchor_node** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **thread** → `UNKNOWN` via `UNKNOWN` (pat_overlay)

## Baseline backbone

- **name**: Olivia Nguyen
- **title**: QA & Testing Engineer
- **department**: Diagnostics
- **seniority**: Contributor
- **blurb**: None
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []