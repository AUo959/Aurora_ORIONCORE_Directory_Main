# Dr. Amina Velin

- **Title:** Lead – Symbolic Systems Researcher
- **Role:** Lead – Symbolic Systems Researcher
- **Department:** Cross-Domain R&D
- **Seniority:** Senior
- **Status:** active
- **Visibility:** Available
- **Anchor node:** aurora.rnd.crossdomain.query
- **Thread:** Unwritten Maps
- **Confidence:** high

## Blurb

Researches symbolic system resonance across interlinked architecture domains.

## Evidence receipts

- **title** → `Lead – Symbolic Systems Researcher` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Lead – Symbolic Systems Researcher` via `Staff_PAT_Registry_v2.2.5.json` (overlay_then_legacy_then_title_fallback)
- **department** → `Cross-Domain R&D` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **seniority** → `Senior` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **blurb** → `Researches symbolic system resonance across interlinked architecture domains.` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `Available` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **anchor_node** → `aurora.rnd.crossdomain.query` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **thread** → `Unwritten Maps` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)

## PAT overlay

- **name**: Dr. Amina Velin
- **department**: Cross-Domain R&D
- **role**: Lead – Symbolic Systems Researcher
- **status**: Active
- **visibility**: Available
- **anchor_node**: aurora.rnd.crossdomain.query
- **thread**: Unwritten Maps

## Baseline backbone

- **name**: Dr. Amina Velin
- **title**: Lead – Symbolic Systems Researcher
- **department**: Cross-Domain R&D
- **seniority**: Senior
- **blurb**: Researches symbolic system resonance across interlinked architecture domains.
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []