# Keira Halden

- **Title:** Lead Visual Concept Designer
- **Role:** Lead Visual Concept Designer
- **Department:** UI/UX
- **Seniority:** Contributor
- **Status:** active
- **Visibility:** UNKNOWN
- **Anchor node:** UNKNOWN
- **Thread:** UNKNOWN
- **Confidence:** low

## Blurb

UNKNOWN

## Evidence receipts

- **title** → `Lead Visual Concept Designer` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Lead Visual Concept Designer` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (overlay_then_legacy_then_title_fallback)
- **department** → `UI/UX` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **seniority** → `Contributor` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **blurb** → `UNKNOWN` via `UNKNOWN` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **anchor_node** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **thread** → `UNKNOWN` via `UNKNOWN` (pat_overlay)

## Baseline backbone

- **name**: Keira Halden
- **title**: Lead Visual Concept Designer
- **department**: UI/UX
- **seniority**: Contributor
- **blurb**: None
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []