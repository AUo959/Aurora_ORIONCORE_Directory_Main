# Dante Kyros

- **Title:** UI/UX Mockup Architect
- **Role:** UI/UX Mockup Architect
- **Department:** Visual Concepts & UI/UX
- **Seniority:** Core Contributor
- **Status:** active
- **Visibility:** UNKNOWN
- **Anchor node:** UNKNOWN
- **Thread:** UNKNOWN
- **Confidence:** medium

## Blurb

Shapes intuitive interfaces that embody the symbolic tone of the simulation. Function and form in harmony.

## Evidence receipts

- **title** → `UI/UX Mockup Architect` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `UI/UX Mockup Architect` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (overlay_then_legacy_then_title_fallback)
- **department** → `Visual Concepts & UI/UX` via `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` (alias_expansion_from_enriched_view)
- **seniority** → `Core Contributor` via `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` (prefer_enriched_non_generic_rank)
- **blurb** → `Shapes intuitive interfaces that embody the symbolic tone of the simulation. Function and form in harmony.` via `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **anchor_node** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **thread** → `UNKNOWN` via `UNKNOWN` (pat_overlay)

## Alternate observations

- **department:** UI/UX [Aurora_GUMAS_Staff_Tracker_v2.2.5.json]
- **seniority:** Contributor [Aurora_GUMAS_Staff_Tracker_v2.2.5.json]
- **blurb:** Dante shapes intuitive interfaces that embody the symbolic tone of the simulation. Function and form in harmony. [Aurora_GUMAS_Staff_Registry_v2.2.5.html]

## Baseline backbone

- **name**: Dante Kyros
- **title**: UI/UX Mockup Architect
- **department**: UI/UX
- **seniority**: Contributor
- **blurb**: None
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []