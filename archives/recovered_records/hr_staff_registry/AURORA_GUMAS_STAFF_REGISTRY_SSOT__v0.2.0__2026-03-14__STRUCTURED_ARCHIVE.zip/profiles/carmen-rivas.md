# Carmen Rivas

- **Title:** Simulation Bindings Specialist
- **Role:** Simulation Bindings Specialist
- **Department:** Core Development
- **Seniority:** Contributor
- **Status:** active
- **Visibility:** Available
- **Anchor node:** aurora.dev.code.query
- **Thread:** UNKNOWN
- **Confidence:** high

## Blurb

Handles binding layers for simulation-thread coupling and temporal sequence control.

## Evidence receipts

- **title** → `Simulation Bindings Specialist` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Simulation Bindings Specialist` via `Staff_PAT_Registry_v2.2.5.json` (overlay_then_legacy_then_title_fallback)
- **department** → `Core Development` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **seniority** → `Contributor` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **blurb** → `Handles binding layers for simulation-thread coupling and temporal sequence control.` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `Available` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **anchor_node** → `aurora.dev.code.query` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **thread** → `UNKNOWN` via `UNKNOWN` (pat_overlay)

## PAT overlay

- **name**: Carmen Rivas
- **department**: Core Development
- **role**: Simulation Bindings Specialist
- **status**: Active
- **visibility**: Available
- **anchor_node**: aurora.dev.code.query
- **thread**: None

## Baseline backbone

- **name**: Carmen Rivas
- **title**: Simulation Bindings Specialist
- **department**: Core Development
- **seniority**: Contributor
- **blurb**: Handles binding layers for simulation-thread coupling and temporal sequence control.
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []