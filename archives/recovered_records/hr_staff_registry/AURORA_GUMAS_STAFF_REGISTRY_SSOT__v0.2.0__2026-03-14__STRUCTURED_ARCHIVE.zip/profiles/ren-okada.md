# Ren Okada

- **Title:** Systems Portability Specialist
- **Role:** Systems Portability Specialist
- **Department:** Systems Portability
- **Seniority:** Contributor
- **Status:** active
- **Visibility:** UNKNOWN
- **Anchor node:** UNKNOWN
- **Thread:** UNKNOWN
- **Confidence:** low

## Blurb

UNKNOWN

## Evidence receipts

- **title** → `Systems Portability Specialist` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Systems Portability Specialist` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (overlay_then_legacy_then_title_fallback)
- **department** → `Systems Portability` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **seniority** → `Contributor` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **blurb** → `UNKNOWN` via `UNKNOWN` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **anchor_node** → `UNKNOWN` via `UNKNOWN` (pat_overlay)
- **thread** → `UNKNOWN` via `UNKNOWN` (pat_overlay)

## Baseline backbone

- **name**: Ren Okada
- **title**: Systems Portability Specialist
- **department**: Systems Portability
- **seniority**: Contributor
- **blurb**: None
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []