# Tobias Qin

- **Title:** Code/Narrative Bridge Mapper
- **Role:** Code/Narrative Bridge Mapper
- **Department:** Core Development
- **Seniority:** Contributor
- **Status:** active
- **Visibility:** Available
- **Anchor node:** aurora.dev.code.query
- **Thread:** UNKNOWN
- **Confidence:** high

## Blurb

Aligns storytelling architecture with structural code logic across dev layers.

## Evidence receipts

- **title** → `Code/Narrative Bridge Mapper` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (source_precedence)
- **role** → `Code/Narrative Bridge Mapper` via `Staff_PAT_Registry_v2.2.5.json` (overlay_then_legacy_then_title_fallback)
- **department** → `Core Development` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **seniority** → `Contributor` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone)
- **blurb** → `Aligns storytelling architecture with structural code logic across dev layers.` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (blurb_precedence)
- **status** → `active` via `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` (backbone_then_overlay)
- **visibility** → `Available` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **anchor_node** → `aurora.dev.code.query` via `Staff_PAT_Registry_v2.2.5.json` (pat_overlay)
- **thread** → `UNKNOWN` via `UNKNOWN` (pat_overlay)

## PAT overlay

- **name**: Tobias Qin
- **department**: Core Development
- **role**: Code/Narrative Bridge Mapper
- **status**: Active
- **visibility**: Available
- **anchor_node**: aurora.dev.code.query
- **thread**: None

## Baseline backbone

- **name**: Tobias Qin
- **title**: Code/Narrative Bridge Mapper
- **department**: Core Development
- **seniority**: Contributor
- **blurb**: Aligns storytelling architecture with structural code logic across dev layers.
- **tags**: []
- **status**: active
- **anchor_code**: None
- **memory_links**: []
- **symbolic_roles**: []