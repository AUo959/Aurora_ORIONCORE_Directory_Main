# Staff Registry SSOT Resolution Log

Source backbone: `Aurora_GUMAS_Staff_Tracker_v2.2.5.json`  
Operational overlay: `Staff_PAT_Registry_v2.2.5.json`

## Deterministic rules

1. Identity roster comes from the 27-person tracker JSON.
2. PAT values override only PAT-specific fields: `role` (when present), `visibility`, `anchor_node`, and `thread`.
3. Department conflicts are resolved by alias expansion only when the enriched HTML view carries a strict expansion observed alongside the tracker value.
4. Seniority conflicts are resolved by preferring enriched non-generic ranks from `Aurora_GUMAS_Complete_Staff_Registry_v2.2.5.html` over baseline `Contributor`.
5. Blurbs prefer staff-registry views over legacy module-specific blurbs.
6. Missing fields remain null; no synthetic biographies or anchors were invented.

## Outcome summary

- Total staff: **27**
- High confidence: **14**
- Medium confidence: **8**
- Low confidence: **5**
- Department alias expansions applied: **7**
- Seniority overrides applied: **8**
- Profiles still lacking blurbs: **5**

## Review notes

The output is a **canonical SSOT candidate**, not an oracle. Every selected value keeps its source receipt and alternate observations so later normalization can tighten the registry without losing evidence.
