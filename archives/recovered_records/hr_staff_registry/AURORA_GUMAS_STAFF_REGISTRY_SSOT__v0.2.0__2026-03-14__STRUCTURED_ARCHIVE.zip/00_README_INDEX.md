# AURORA_GUMAS_STAFF_REGISTRY_SSOT — Structured Archive

This bundle converts the prior catalog into a **canonical staff registry SSOT candidate** for the Aurora/GUMAS staff set.

## Included artifacts

- `data/aurora_gumas_staff_registry_ssot.v1.json` — canonical per-person registry with receipts and alternates
- `data/aurora_gumas_staff_registry_ssot.v1.csv` — flat table for filtering/sorting
- `profiles/*.md` — one evidence-backed profile per individual
- `reports/conflict_resolution_matrix.*` — field-by-field conflict outcomes
- `reports/staff_profile_gaps.*` — remaining missing-field inventory
- `reports/ssot_resolution_log.md` — deterministic resolution policy and summary
- `governance/ADR_LITE.md` — backbone/overlay decision record
- audit spine: `RUN_LOCK.json`, `BUILD_RECEIPT.json`, `bundle.manifest.json`, `audit/*`

## Summary

- Total staff: **27**
- Confidence split: **{'medium': 8, 'high': 14, 'low': 5}**
- PAT overlay records: **9**
- Profiles missing blurbs: **5**

## Important note

This bundle is intentionally conservative. Missing values remain missing, and every chosen canonical value keeps the evidence needed to revisit the decision later.
