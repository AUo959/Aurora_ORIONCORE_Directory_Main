# ADR-LITE — Staff Registry SSOT Candidate

- **Decision:** Use `Aurora_GUMAS_Staff_Tracker_v2.2.5.json` as the roster backbone for the canonical staff registry.
- **Why:** It is the only machine-readable source that covers all 27 individuals with stable per-person records.
- **Overlay:** Use `Staff_PAT_Registry_v2.2.5.json` only for PAT-specific operational fields.
- **Tradeoff:** This favors completeness and determinism over maximum narrative richness.
- **Consequence:** Expanded HTML views can enrich blurbs, departments, and seniority, but every such override remains receipt-backed and reversible.
